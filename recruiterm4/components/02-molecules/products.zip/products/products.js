import '../../../node_modules/wowjs/dist/wow.min';

// eslint-disable-next-line no-undef
new WOW().init();
