<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* modules/contrib/progress_bar/templates/progress-bar-format.html.twig */
class __TwigTemplate_dfc76298d1cb148b8d9c3cf07a92a53f extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->env->getExtension('\Twig\Extension\SandboxExtension');
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 12
        echo "<div class=\"progress-bar-wrapper\">
    ";
        // line 13
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["state"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 14
            echo "\t\t<div class=\"progress-bar-formatter\" role=\"progressbar\" style=\"width: ";
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, $context["item"], "lowest_percent", [], "any", false, false, true, 14), 14, $this->source), "html", null, true);
            echo "%; background-color: ";
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, $context["item"], "color", [], "any", false, false, true, 14), 14, $this->source), "html", null, true);
            echo "\" aria-valuemin=\"0\" aria-valuemax=\"100\" aria-valuenow=\"";
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, $context["item"], "state", [], "any", false, false, true, 14), 14, $this->source), "html", null, true);
            echo "\">
\t\t\t<span class=\"progress-bar-name\">";
            // line 15
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, $context["item"], "name", [], "any", false, false, true, 15), 15, $this->source), "html", null, true);
            echo "</span>
\t\t</div>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 18
        echo "</div>
";
    }

    public function getTemplateName()
    {
        return "modules/contrib/progress_bar/templates/progress-bar-format.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  64 => 18,  55 => 15,  46 => 14,  42 => 13,  39 => 12,);
    }

    public function getSourceContext()
    {
        return new Source("{#
/**
 * @file
 * Template for the progress bar.
 *
 * Available variables:
 * - state: Array which contain name, color, percentage.
 *
 * @ingroup themeable
 */
#}
<div class=\"progress-bar-wrapper\">
    {% for item in state %}
\t\t<div class=\"progress-bar-formatter\" role=\"progressbar\" style=\"width: {{ item.lowest_percent }}%; background-color: {{ item.color }}\" aria-valuemin=\"0\" aria-valuemax=\"100\" aria-valuenow=\"{{ item.state }}\">
\t\t\t<span class=\"progress-bar-name\">{{ item.name }}</span>
\t\t</div>
    {% endfor %}
</div>
", "modules/contrib/progress_bar/templates/progress-bar-format.html.twig", "/var/www/rishabh_php/BizLand/web/modules/contrib/progress_bar/templates/progress-bar-format.html.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = array("for" => 13);
        static $filters = array("escape" => 14);
        static $functions = array();

        try {
            $this->sandbox->checkSecurity(
                ['for'],
                ['escape'],
                []
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
